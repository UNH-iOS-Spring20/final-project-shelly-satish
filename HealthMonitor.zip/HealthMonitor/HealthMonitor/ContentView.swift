//
//  ContentView.swift
//  HealthMonitor
//
//  Created by shelly choudhary on 2/20/20.
//  Copyright © 2020 shelly choudhary. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
